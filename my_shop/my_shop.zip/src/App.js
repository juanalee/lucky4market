// src/App.js
import React from 'react';
import MyShop from './components/MyShop';

function App() {
  return (
    <div className="App">
      <MyShop/>
    </div>
  );
}

export default App;